const char CCACHE_VERSION[] = "unknown";
