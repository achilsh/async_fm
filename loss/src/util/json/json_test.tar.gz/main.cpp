#include <stdio.h>
#include "CJsonObject.hpp"

int main()
{
    std::string strJson = "{\"list\":[{\"myBean\":{\"cardNum\":[\"农行\",\"工行\",\"建行\"],"
                    "\"cardType\":[\"身份证\",\"银行卡\",\"公交卡\"],"
                    "\"date\":{\"date\":31,\"day\":4,\"hours\":16,\"minutes\":39,\"month\":0,"
                    "\"seconds\":53,\"time\":1359621593125,\"timezoneOffset\":-480,\"year\":113},"
                    "\"id\":\"001\",\"name\":\"银行卡\"},\"name\":\"langfei\"},"
                    "{\"myBean\":{\"cardNum\":[\"农行\",\"工行\",\"建行\"],"
                    "\"cardType\":[\"身份证\",\"银行卡\",\"公交卡\"],\"date\":{\"date\":1,\"day\":5,"
                    "\"hours\":16,\"minutes\":39,\"month\":0,\"seconds\":53,\"time\":1359621593123,"
                    "\"timezoneOffset\":-480,\"year\":113},\"id\":\"001\",\"name\":\"银行卡\"},"
                    "\"name\":\"langfei2\"}],"
                    "\"map\":{\"personA\":{\"myBean\":{\"cardNum\":[\"农行\",\"工行\",\"建行\"],"
                    "\"cardType\":[\"身份证\",\"银行卡\",\"公交卡\"],\"date\":{\"date\":31,\"day\":4,"
                    "\"hours\":16,\"minutes\":39,\"month\":0,\"seconds\":53,\"time\":1359621593125,"
                    "\"timezoneOffset\":-480,\"year\":113},\"id\":\"001\",\"name\":\"银行卡\"},"
                    "\"name\":\"langfeA\"},"
                    "\"personB\":{\"myBean\":{\"cardNum\":[\"农行\",\"工行\",\"建行\"],"
                    "\"cardType\":[\"身份证\",\"银行卡\",\"公交卡\"],\"date\":{\"date\":31,\"day\":4,"
                    "\"hours\":16,\"minutes\":39,\"month\":0,\"seconds\":53,\"time\":1359621593125,"
                    "\"timezoneOffset\":-480,\"year\":113},\"id\":\"001\",\"name\":\"银行卡\"},"
                    "\"name\":\"langfeiB\"}}}";
    loss::CJsonObject oObj(strJson);
    printf("%s\n", oObj.ToString().c_str());
    printf("=============================================================\n");
    printf("%s\n", oObj["list"][1]["myBean"]["cardType"](1).c_str());
    printf("%s\n", oObj["map"]["personA"]["myBean"]["date"]("time").c_str());
    return(0);
}
